# Original open-magnetar guests

Source: https://github.com/Lulzx/open-magnetar/tree/febfc0e66f5809e034dd1afac78202bd4882de27/guest

The following source files are byte-for-byte copies from revision `febfc0e66f5809e034dd1afac78202bd4882de27`:

| Local file | Upstream file |
| --- | --- |
| `examples/binary-search.c` | `guest/examples/binary-search.c` |
| `examples/erc20-mixed-block.c` | `guest/examples/erc20-mixed-block.c` |
| `examples/pointer-chase.c` | `guest/examples/pointer-chase.c` |
| `rt/start.S` | `guest/rt/start.S` |
| `rt/om.h` | `guest/rt/om.h` |
| `link.ld` | `guest/link.ld` |

Upstream root `LICENSE-MIT` and `LICENSE-APACHE` are included. The guest sources are used under the repository's MIT OR Apache-2.0 license.

Each ELF is compiled from its unchanged upstream source and the shared runtime/linker files with freestanding RV64I flags. The RAM address space is A=16 and input region is I=12 for every program. Each manifest records source hashes, the ELF hash, its full build command, and compiler/linker versions.

| Program / ELF | Output ABI | Manifest |
| --- | --- | --- |
| `binary-search.elf` | O=8 | `fixture.json` |
| `erc20-mixed-block.elf` | O=11 | `erc20-mixed-block.fixture.json` |
| `pointer-chase.elf` | O=8 | `pointer-chase.fixture.json` |

The ERC-20 output region accommodates the success count and all 1,024 account balances allowed by the original source. Its output region differs from the binary-search fixture's region size; its C source is unchanged. The original binary-search ELF and manifest retain their existing ABI and hashes.

Rebuild one program with `python3 scripts/build_guest.py --program erc20-mixed-block`, or all three with `python3 scripts/build_guest.py --program all`. Omitting `--program` rebuilds binary-search as before. Builds use an installed Clang and LLD without downloading dependencies; `--clang`/`CLANG` and `LD_LLD` can select the tools. See `docs/payloads.md` for execution, address mapping and trace-fill semantics. A RAM pattern derived from a source execution is distinct from proving that program's CPU execution.
